Name: Stylelint
Id: stylelint.vscode-stylelint
Description: Official Stylelint extension for Visual Studio Code
Version: 1.2.4
Publisher: Stylelint
VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=stylelint.vscode-stylelint